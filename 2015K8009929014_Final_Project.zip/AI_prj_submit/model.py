# coding=utf8
'''
You should compelte this code.
I suggest you to write your email and mobile phone number here
#############  Contact information   ##############
email: yaoyuhao15@mails.ucas.ac.cn
phone: 15710035188
############  Contact information end  ############
'''
###############   import start    #################
from __future__ import print_function
from my_lstm import use_model
import numpy as np
import json
##############     import end     #################

def predict(input_file_path, output_file_path):
    sentence_list   = json.load(open(input_file_path, 'r'))
    Num_sentence    = len(sentence_list)
    sentenceId      = []
    X               = []
    output          = []
    
    print("Total sentence:", Num_sentence)
    
    for i in range(Num_sentence):
        indexes = sentence_list[i]['indexes']
        sen_id  = sentence_list[i]['sentenceId']
        n_word  = len(indexes)
        for j in range(n_word): indexes[j] += 2
        X.append(indexes[:])
        sentenceId.append(sen_id)
    results     = use_model(X[:])
    for i in range(Num_sentence): output.append({"sentenceId": sentenceId[i], "results": results[i]})
    json.dump(output, open(output_file_path, 'w'))
    print("Predict finished!")