"""Built-in loss functions.
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import six
from . import backend as K
from .utils.generic_utils import deserialize_keras_object
from .utils.generic_utils import serialize_keras_object


def my_loss(y_true, y_pred):
    y_id = K.argmax(y_true, axis = 2) - 1
    tmp = K.sum((y_pred - y_true) * (y_pred - y_true), axis = 2)
    return K.sum(y_id * y_id * tmp, axis=-1)

def my_loss_sq(y_true, y_pred):
    return K.mean(y_true * y_true * (y_pred - y_true) * (y_pred - y_true), axis = -1)

# Aliases.


def serialize(loss):
    return serialize_keras_object(loss)


def deserialize(name, custom_objects=None):
    return deserialize_keras_object(name,
                                    module_objects=globals(),
                                    custom_objects=custom_objects,
                                    printable_module_name='loss function')


def get(identifier):
    if identifier is None:
        return None
    if isinstance(identifier, six.string_types):
        identifier = str(identifier)
        return deserialize(identifier)
    if isinstance(identifier, dict):
        return deserialize(identifier)
    elif callable(identifier):
        return identifier
    else:
        raise ValueError('Could not interpret '
                         'loss function identifier:', identifier)
